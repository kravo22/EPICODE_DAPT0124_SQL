-- Quale è la query da eseguire per verificare quante unità di un prodotto ci sono in un determinato magazzino ?

-- Verifica prodotto in magazzino per nome

select
	Warehouse_Id,
    Product_Name,
	Inventory_Quantity
from
	inventory i
join
	product p
on
	p.Product_Id = i.Product_Id
where
	Product_Name = 'Smartphone' and Warehouse_Id = 1; -- Possiamo ricercare la quantità di un prodotto nel magazzino di riferimento