-- Creazione Database

create database
	VendiCose_SpA;

use
	VendiCose_SpA;

create table category (
	Category_Id INT primary key,
	Category_Name VARCHAR(100),
    Category_Supplier VARCHAR(100)
);

create table warehouse (
	Warehouse_Id INT primary key,
	Warehouse_Name VARCHAR(100),
    Warehouse_Address VARCHAR(100)
);

create table shop (
	Shop_Id INT primary key,
	Warehouse_Id INT,
	Shop_Address VARCHAR(100),
	Shop_Name VARCHAR(100),
	foreign key (Warehouse_Id) references warehouse(Warehouse_Id)
);

create table product (
	Product_Id INT primary key,
	Category_Id INT,
	Product_Name VARCHAR(100),
	foreign key (Category_Id) references category(Category_Id)
);

create table sales (
	Sales_Id INT primary key,
	Shop_Id INT,
	Sales_Date DATE,
	foreign key (Shop_Id) references shop(Shop_Id)
);

create table sales_detail (
	Sales_Id INT,
	Sales_Detail_Id INT,
	Product_Id INT,
	Sales_Quantity INT,
	primary key (Sales_Id, Sales_Detail_Id),
	foreign key (Product_Id) references product(Product_Id),
    foreign key (Sales_Id) references sales(Sales_Id)
);

create table restock (
	Warehouse_Id INT,
	Category_Id INT,
	Restock_Level INT,
	primary key (Warehouse_Id, Category_Id),
	foreign key (Warehouse_Id) references warehouse(Warehouse_Id),
	foreign key (Category_Id) references category(Category_Id)
);

create table inventory (
	Warehouse_Id INT,
	Product_Id INT,
	Inventory_Quantity INT,
	primary key (Warehouse_Id, Product_Id),
	foreign key (Warehouse_Id) references warehouse(Warehouse_Id),
	foreign key (Product_Id) references product(Product_Id)
);