-- Quale è la query da eseguire per monitorare le soglie di restock ?

-- Monitoraggio livelli Restock in un determinato magazzino

select
	p.Product_Id,
    p.Product_Name,
    i.Inventory_Quantity,
    r.Restock_Level
from
	product p
join
	inventory i
on
	p.Product_Id = i.Product_Id
join
	category c
on
	p.Category_Id = c.Category_Id
join
	restock r
on
	c.Category_Id = r.Category_Id and i.Warehouse_Id = r.Warehouse_Id
where
	i.Warehouse_Id = 1	and i.Inventory_Quantity <= r.Restock_Level; -- Bisogna inserire solo in Warehouse_Id del magazzino di riferimento