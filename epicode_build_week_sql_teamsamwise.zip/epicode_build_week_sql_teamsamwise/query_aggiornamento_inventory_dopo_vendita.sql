-- Ogni qual volta un prodotto viene venduto in un negozio, qual è la query da eseguire per aggiornare le tabelle di riferimento?

-- Aggiornamento dopo vendita per 1 prodotto

update
	Inventory
set
	Inventory_Quantity = Inventory_Quantity - (
		select
			Sales_Quantity
		from
			Sales_Detail
		where
			Sales_Id = 21 -- va inserito il Sales_Id della nuova vendita generata 
		)
where
	Warehouse_Id = (
		select
			Warehouse_Id
		from
			shop
		where
			Shop_Id = (
				select
					Shop_Id
				from
					sales
				where
					Sales_Id = 21 -- va inserito il Sales_Id della nuova vendita generata
				)
		)
  and
	Product_Id = (
		select
			Product_Id
		from
			sales_detail
		where
			Sales_Id = 21 -- va inserito il Sales_Id della nuova vendita generata
);