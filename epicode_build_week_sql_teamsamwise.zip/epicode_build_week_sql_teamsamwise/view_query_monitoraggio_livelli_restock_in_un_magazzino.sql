-- Monitoraggio livelli Restock in un determinato magazzino

create view Warehose_Restock_Level
as (
select
	p.Product_Id,
    p.Product_Name,
    i.Inventory_Quantity,
    r.Restock_Level
from
	product p
join
	inventory i
on
	p.Product_Id = i.Product_Id
join
	category c
on
	p.Category_Id = c.Category_Id
join
	restock r
on
	c.Category_Id = r.Category_Id and i.Warehouse_Id = r.Warehouse_Id
where
	i.Warehouse_Id = 1	and i.Inventory_Quantity <= r.Restock_Level -- Abbiamo immaginato che ad un negozio interessi solamente sapere le quantità nel proprio magazzino di riferimento
);