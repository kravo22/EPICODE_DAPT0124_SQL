-- Inserire nuova vendita per 1 prodotto

insert into sales (Sales_Id, Shop_Id, Sales_Date) values
(21, 1, '2024-03-29'); -- ho inserito 21 perchè è il numero successivo dopo la popolazione del database

insert into sales_detail (Sales_Id, Sales_Detail_Id, Product_Id, Sales_Quantity) values
(21, 1, 1, 10);